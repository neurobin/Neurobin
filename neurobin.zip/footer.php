		<div class="container-fluid" id="foot" >
			<div class="row" id="footer">

				<div class="col-xs-4">
					<a href="#" id="sitemap">SiteMap</a>
					<div id="sitemap-poem">
						Take The Tour
						<br />
						Explore The Site
						<br />
						From One Place
						<br />
						Day Or Night
						<br />
					</div>
				</div>
				<div class="col-xs-4">

					<ul id="footer-links">
						<li>
							<p id="suggested-links">
								Suggested Links
							</p>
						</li>
						<li>
							<a href="shc">SHC</a>
						</li>
						<li>
							<a href="tartos">Tartos</a>
						</li>
						<li>
							<a href="JLIVECD">JLIVECD</a>
						</li>
						<li>
							<a href="https://play.google.com/store/apps/details?id=com.jsoft.tictactoe">Tic Tac Toe</a>
						</li>
						<li>
							<a href="#">29 (Card Game)</a>
						</li>
						<li>
							<p id="copyright">
								&copy; 2015, Neurobin, All rights reserved.
							</p>
						</li>
					</ul>
				</div>
				<div class="col-xs-4">
					<p id="share-title">
						Share Me:
					</p>
					<div class="share-buttons">
						<a href="http://www.facebook.com/sharer.php?u=http://neurobin.github.io/" onclick="return newShareWindow(this.href,400,400)" class="btn btn-social btn-facebook"><i class="fa fa-facebook"></i> share</a>
						<a href="http://twitter.com/home?status=http://neurobin.github.io/" onclick="return newShareWindow(this.href,400,400)" class="btn btn-social btn-twitter"><i class="fa fa-twitter"></i> share</a>

					</div>

				</div>

			</div>
		</div>